public class Simulation {
	
	public static void main (String [] args) {
	
	}

}
