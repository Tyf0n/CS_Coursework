package Ethernet;
import java.util.UUID;
import java.util.HashMap;
import java.lang.Math;
import java.util.Random;

public class Host {

    int hostId;	
    int repeaterIndex;

    Transmitter tstate;
    Receiver rstate;
    SimulatedTime stime;
    Random r = new Random();
    int transAttempt = 0;
    int processTime;
    int packetsToSend = 2;
    int packetSize;

    HashMap<UUID, SimulatedEvent> upcomingEvents;

    // obsolete measure
    //int position; // define this to be the time units from the left-most edge
    // of the network

    //int repeaterIndex;

    public static double PREAMBLE_TIME = 64.0;
    public static double GAP_TIME = 96.0;
    public static double JAMMING_TIME = 32.0;
    public static double SLOT_TIME = 512.0;


    // number of feet per bit
    public static double FEET_PER_BIT = 65.6167979;


    // distance to nearest repeater in feet
    public static double DISTANCE_TO_REPEATER = 20;
    // distance between two hosts excluding the distance of their repeaters
    public static double BIT_DISTANCE_BETWEEN_TWO_HOSTS = 2 * DISTANCE_TO_REPEATER / FEET_PER_BIT;

    


    public Host(SimulatedTime parentTime, int pSize, int inID)
    {
	hostId = inID;
	Double grpOfSix = new Double(Math.floor(inID / 6.0));
	repeaterIndex = grpOfSix.intValue();

	tstate = Transmitter.PREPARING;
	rstate = Receiver.IDLE;

	stime = parentTime;

	packetSize = pSize;

	//position = curPos;
	processTime = 10;//Should be random later
    }


    public double BitDistanceFromAnotherRepeaterIndex(int otherRptInd)
    {
	return Math.abs(repeaterIndex - otherRptInd) * 1000.0 / FEET_PER_BIT;
    }

    public void AddFutureEvent(SimulatedEvent simEvt)
    {
	upcomingEvents.put(simEvt.ID, simEvt);
    }

    public boolean isMyEvent(SimulatedEvent e){
	return e.hostCreated == this.hostId;
    }

    public void scheduleMyEvent(SimulatedEvent.SimEvtType type, double startoffset, double dur, boolean justMyself){
	UUID id = UUID.randomUUID();
	double currentTime = stime.getCurrentTime();
	SimulatedEvent event = new SimulatedEvent(id, type, currentTime + startoffset, dur, this.hostId, repeaterIndex ,justMyself);
	AddFutureEvent(event);
	stime.schedule(event);	
    }

	public void reactToEvent(SimulatedEvent e) {

            double relpos = BIT_DISTANCE_BETWEEN_TWO_HOSTS + BitDistanceFromAnotherRepeaterIndex(e.RepeaterIndexOfHost);

	    // obsolete
	    //Math.abs(this.position - e.origin);
	    //Figure out the relative position of me with respect to where the event originated.	    

	    //Determine the state changes of the receiver
	    switch (rstate) {

			case BUSY:				
				//Line is busy.  If we see the end of a transmission or jamming.
				if (e.getEventType() == SimulatedEvent.SimEvtType.JAMMING_DONE || 
				    e.getEventType() == SimulatedEvent.SimEvtType.TRANS_DONE ){

					//If:   The END I see came from another host AND I am supposed to see it.
					//	Reschedule the END so it's my END and only I can see it.
					//Else: Take this rescheduled event, now I experience the event, Go to Gap state, 
					//	and schedule for myself when the gap is over   
					
					if ( !isMyEvent(e) && !e.justMyself ){
						scheduleMyEvent(SimulatedEvent.SimEvtType.TRANS_DONE, relpos , 0, true);
					} else if (e.justMyself && isMyEvent(e)){
						rstate = Receiver.GAP;
						scheduleMyEvent(SimulatedEvent.SimEvtType.GAP_DONE, GAP_TIME, 0, true);
					}

				}

				break;
			case GAP:
				//If I see that MY Gap time is over, then schedule a notification to myself that 
				//My receiver is now idle, and move to the idle state.

				if (isMyEvent(e) && e.getEventType() == SimulatedEvent.SimEvtType.GAP_DONE)  {
					
				    scheduleMyEvent(SimulatedEvent.SimEvtType.R_NOW_IDLE, 0, 0, true);
				    rstate = Receiver.IDLE;
				}

				break;
			case IDLE:				

				//If:	The line is idle and we see the start of a signal
					
				if ((e.getEventType() == SimulatedEvent.SimEvtType.JAMMING_START  ||
				     e.getEventType() == SimulatedEvent.SimEvtType.PREAMBLE_START ||
				     e.getEventType() == SimulatedEvent.SimEvtType.TRANS_START    ))  {
					
					//If:   The START I see came from another host AND I am supposed to see it.
					//	Reschedule the START so it's my START and only I can see it.
					//Else: Take this rescheduled event, now I experience the event, Go to BUSY state, 
					//	and schedule a notification for myself that the receiver has become busy.

					if ( !isMyEvent(e) && !e.justMyself ) {
						scheduleMyEvent(SimulatedEvent.SimEvtType.TRANS_START,relpos, 0, true);
					} else if (e.justMyself && isMyEvent(e)){
						scheduleMyEvent(SimulatedEvent.SimEvtType.R_NOW_BUSY, 0, 0, true);
				  		rstate = Receiver.BUSY;
					}
				}
				
				break;
	    }
	    
	    switch (tstate) {
			case EAGER: 
				//I am eager to send packets, and I see that MY receiver is idle, I start my preamble, and schedule when I end.

				if (e.getEventType() == SimulatedEvent.SimEvtType.R_NOW_IDLE && isMyEvent(e) ) {
				    scheduleMyEvent(SimulatedEvent.SimEvtType.PREAMBLE_START, 0, 0, false);
				    scheduleMyEvent(SimulatedEvent.SimEvtType.PREAMBLE_DONE, PREAMBLE_TIME, 0, true);
				    tstate = Transmitter.PREAMBLE;
				}

				break;
			case PREAMBLE:
				// I am transmitting my preamble, when MY preamble is done, 
				// If:   Receiver is idle, start packet, schedule packet end, go to sending state
				// Else: Collision occurred so start jamming, schedule jamming end, go to jamming state.

				if (e.getEventType() == SimulatedEvent.SimEvtType.PREAMBLE_DONE && isMyEvent(e) ) {
					if (rstate == Receiver.IDLE) {
					    scheduleMyEvent(SimulatedEvent.SimEvtType.TRANS_START, 0, 0, false);
					    scheduleMyEvent(SimulatedEvent.SimEvtType.TRANS_DONE, packetSize, 0, false);
					    tstate = Transmitter.SENDING;
					} else {
					    scheduleMyEvent(SimulatedEvent.SimEvtType.JAMMING_START, 0, 0, false);
					    scheduleMyEvent(SimulatedEvent.SimEvtType.JAMMING_DONE, JAMMING_TIME, 0, false);
					    tstate = Transmitter.JAMMING;
					}
				}

				break;
			case JAMMING:
				//I be jammin'. Yeah mun BIG TIME.  If my jamming is done.  Schedule when my backoff will be over
				//Increment the transAttempt.  Go to WAITING backoff slots state.  
				
				if (e.getEventType() == SimulatedEvent.SimEvtType.JAMMING_DONE && isMyEvent(e)) {

				    int maxWaitSlots = 1023; // 2 ^ 10 - 1

				    if(transAttempt < 10)
					{
					    Double power = new Double(Math.pow(2.0, transAttempt));
					    maxWaitSlots = power.intValue() - 1;
					}

				    if (transAttempt <= 10) {
				   	 scheduleMyEvent(SimulatedEvent.SimEvtType.BACKOFF_DONE,SLOT_TIME *((double)r.nextInt(maxWaitSlots)), 0, true);
				    } else {
					 scheduleMyEvent(SimulatedEvent.SimEvtType.BACKOFF_DONE,SLOT_TIME *((double)r.nextInt(maxWaitSlots)), 0, true);
				    }
				    transAttempt++;
				    tstate = Transmitter.WAITING;
				}

				break;
			case SENDING:
				//I am sending packets.  
				//If my receiver has become busy, start jamming, schedule jamming end, go to jamming state
				//Else: If the transmission is complete, If I have no more to send, I'm done 
				//					Else: schedule when the next packet will be ready
				// 					decrement the packetsToSend, go to Preparing

				if (e.getEventType() == SimulatedEvent.SimEvtType.R_NOW_BUSY && isMyEvent(e)) {

					scheduleMyEvent(SimulatedEvent.SimEvtType.JAMMING_START, 0, 0, false);
					scheduleMyEvent(SimulatedEvent.SimEvtType.JAMMING_DONE, JAMMING_TIME, 0, false);
					tstate = Transmitter.JAMMING;

				} else if (e.getEventType() == SimulatedEvent.SimEvtType.TRANS_DONE && isMyEvent(e)) {
					if (packetsToSend > 0 ) {
				        	scheduleMyEvent(SimulatedEvent.SimEvtType.PACKET_READY, processTime, 0, true);
				        	tstate = Transmitter.PREPARING;
						packetsToSend--;
					} else {
						tstate = Transmitter.DONE;
					}										
				}

				break;
			case PREPARING:
	
			       // I'm preparing the next packet.  Once MY packet is ready, 
			       // If the receiver is idle: start preamble, schedule preamble done, go to preamble 
			       // Else: Go to Eagar state
			       if (e.getEventType() == SimulatedEvent.SimEvtType.PACKET_READY && isMyEvent(e)) {
					if (rstate == Receiver.IDLE) {
					     scheduleMyEvent(SimulatedEvent.SimEvtType.PREAMBLE_START, 0, 0, false);
					     scheduleMyEvent(SimulatedEvent.SimEvtType.PREAMBLE_DONE, PREAMBLE_TIME, 0, false);
					     tstate = Transmitter.PREAMBLE;
					} else {
						tstate = Transmitter.EAGER;
					}
				}

			       break;
			case WAITING:

				//If I'm waiting the backoff slots, and I've tried way too many times, abort and move on to the next packet, schedule when its done, prepare
				// Else start the preamble if the reciever is idle, or become eager is receiever is busy.
				if (transAttempt >= 15) {
				    // Packet is Aborted
				    packetsToSend--;
				    transAttempt =0;
				    if (packetsToSend == 0) {
					tstate = Transmitter.DONE;
				    } else {
					scheduleMyEvent(SimulatedEvent.SimEvtType.PACKET_READY, processTime, 0, true);
				        tstate = Transmitter.PREPARING;
				    }
				} else if (e.getEventType() == SimulatedEvent.SimEvtType.BACKOFF_DONE && isMyEvent(e)) {
					if (rstate == Receiver.IDLE) {
					     scheduleMyEvent(SimulatedEvent.SimEvtType.PREAMBLE_START, 0, 0, false);
					     scheduleMyEvent(SimulatedEvent.SimEvtType.PREAMBLE_DONE, PREAMBLE_TIME, 0, false);
					     tstate = Transmitter.PREAMBLE;
					} else {
					     tstate = Transmitter.EAGER;
					}
				}

				break;
		}		
	}



	public enum Transmitter {
		EAGER, PREPARING, PREAMBLE, SENDING, JAMMING, WAITING, DONE
	}

	public enum Receiver {
		BUSY, GAP, IDLE
	}
}
